Heartless is a small adventure game where a soul tries to reunite with its body in the labyrinth of the mind.
Here other souls, the heartless, will try to tear you to pieces to steal the beating heart you have. 
To interact with the objects in the game press the space key, to move wasd, left click to extract the heart, right one to shoot it.
To restart the game from the beginning (without deaths) press esc.
the game is playable in two modes: "trial and error" or "no deaths". 
To be able to complete the game without dying it is necessary to take advantage of the exploration of the level. 
